#ifndef bookmain_H
#define bookmain_H


//#include <jni.h>
//JNIEnv* create_vm();

//int srchbook(JNIEnv*, int eboard[], int side);
int bookmain(char argstr[]);

#endif
